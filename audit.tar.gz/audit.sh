#!/bin/sh
[ -f ./password_report.`date +"%Y-%m-%d"`.txt ]&& rm -f ./password_report.{`date +"%Y-%m-%d"`}.txt
[ -f ./tmp ]&&`rm -f ./tmp`

ERR_COUNT=0
RIGHT_COUNT=0
CANNOT_PING=0
TOTAL=`wc -l ./passfile|awk '{print $1}'`
echo -e "\nCHECKING NOW...\n"
while read i
do
IP=`echo $i|awk '{print $1}'`
PORT=`echo $i|awk '{print $2}'`
USERNAME=`echo $i|awk '{print $3}'`
PASS=`echo $i|awk '{print $4}'`
OWNER=`echo $i|awk '{print $5}'`
ping -c 1 $IP >/dev/null 2>&1
if [ $? -eq 0 ];then
	./expect_ad ${USERNAME} ${IP} ${PASS} ${PORT} >/dev/null 2>&1
	if [ $? -eq 0 ];then
	#	echo "${USERNAME}@${IP} password: $PASS		OK !"
		printf "%s@%-30s%-20s%10s\n" ${USERNAME} ${IP} ${OWNER} "OK !"| tee -a ./tmp
		let RIGHT_COUNT=RIGHT_COUNT+1
	else
	#	echo "${USERNAME}@${IP} password: $PASS		Wrong!!!"
		printf "%s@%-30s%-20s%10s\n" ${USERNAME} ${IP} ${OWNER} "Wrong !"| tee -a ./tmp
		let ERR_COUNT=ERR_COUNT+1
	fi
else
	printf "%s@%-30s%-20s%10s\n" ${USERNAME} ${IP} ${OWNER} "Null !"| tee -a ./tmp
		let CANNOT_PING=CANNOT_PING+1
fi
done < passfile 
echo -e "\nCHECK TIME: `date +"%Y-%m-%d %H:%M:%S"`" |tee ./password_report.`date +"%Y-%m-%d"`.txt
echo "TOTAL ${TOTAL} : ${RIGHT_COUNT} OK!	${ERR_COUNT} Wrong !	${CANNOT_PING} Null !" |tee -a ./password_report.`date +"%Y-%m-%d"`.txt
if [ ${ERR_COUNT} -ne 0 ];then
	echo -e "\n*******************BELOW ARE WRONG PASSWORD LIST:\n" |tee -a ./password_report.`date +"%Y-%m-%d"`.txt
	grep "Wrong" ./tmp |awk 'BEGIN{printf("%s\n","-------------------------")}{printf("%-45s%-10s\n",$1,$2)}END{print "\n"}'|tee -a ./password_report.`date +"%Y-%m-%d"`.txt
	else
		:
fi
if [ ${CANNOT_PING} -ne 0 ];then
	echo -e "\n*******************BELOW ARE CAN NOT PING LIST:\n"|tee -a ./password_report.`date +"%Y-%m-%d"`.txt
	grep "Null" ./tmp |awk 'BEGIN{printf("%s\n","-------------------")}{printf("%-45s%-10s\n",$1,$2)}END{print "\n"}'|tee -a ./password_report.`date +"%Y-%m-%d"`.txt
	else
		:
fi
if [ ${ERR_COUNT} -eq 0 -a ${CANNOT_PING} -eq 0 ];then
	echo -e "\nCONGRATULATIONS!	NO ERRORS!"|tee -a ./password_report.`date +"%Y-%m-%d"`.txt
fi
